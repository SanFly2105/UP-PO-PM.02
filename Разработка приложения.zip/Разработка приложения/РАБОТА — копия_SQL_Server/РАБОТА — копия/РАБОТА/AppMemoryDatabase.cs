using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace РАБОТА
{
    internal sealed class DbItem
    {
        public int Id { get; private set; }
        public string Text { get; private set; }

        public DbItem(int id, string text)
        {
            Id = id;
            Text = text;
        }

        public override string ToString()
        {
            return Text;
        }
    }

    internal static class AppMemoryDatabase
    {
        public static readonly DataTable Objects = CreateTable("Объекты", "Название объекта", "Прораб", "Статус");
        public static readonly DataTable Purchases = CreateTable("Закупки", "Объект", "Материал", "Кол-во", "Приоритет", "Статус", "Комментарий");
        public static readonly DataTable Equipment = CreateTable("Техника", "Название техники", "Тип", "Состояние");
        public static readonly DataTable Employees = CreateTable("Сотрудники", "ФИО", "Телефон", "Адрес", "Должность", "Объект", "Статус", "Зарплата", "Дата приема", "Комментарий");
        public static readonly DataTable Clients = CreateTable("Клиенты", "ФИО", "Телефон", "Статус");

        private static bool isRefreshing;
        private static string activeConnectionString;

        static AppMemoryDatabase()
        {
            EnsureDatabase();
            RefreshAll();

            Objects.RowChanged += SaveObjectRow;
            Purchases.RowChanged += SavePurchaseRow;
            Equipment.RowChanged += SaveEquipmentRow;
            Employees.RowChanged += SaveEmployeeRow;
            Clients.RowChanged += SaveClientRow;
        }

        private static string ConnectionString
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(activeConnectionString))
                {
                    return activeConnectionString;
                }

                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["RabotaDb"];
                if (settings != null && !string.IsNullOrWhiteSpace(settings.ConnectionString))
                {
                    return settings.ConnectionString;
                }

                return @"Data Source=.\SQLEXPRESS;Initial Catalog=RabotaDb;Integrated Security=True;TrustServerCertificate=True";
            }
        }

        private static DataTable CreateTable(string name, params string[] columns)
        {
            DataTable table = new DataTable(name);
            table.Columns.Add("Id", typeof(int));
            foreach (string column in columns)
            {
                table.Columns.Add(column, typeof(string));
            }

            return table;
        }

        private static void EnsureDatabase()
        {
            activeConnectionString = SelectConnectionString();
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(ConnectionString);
            string databaseName = builder.InitialCatalog;
            builder.InitialCatalog = "master";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = "IF DB_ID(@name) IS NULL BEGIN DECLARE @sql NVARCHAR(MAX) = N'CREATE DATABASE ' + QUOTENAME(@name); EXEC(@sql); END";
                command.Parameters.AddWithValue("@name", databaseName);
                command.ExecuteNonQuery();
            }

            ExecuteNonQuery(@"
IF OBJECT_ID('dbo.Objects', 'U') IS NULL
CREATE TABLE dbo.Objects (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ObjectName NVARCHAR(200) NOT NULL,
    Foreman NVARCHAR(200) NOT NULL,
    Status NVARCHAR(100) NOT NULL
);

IF OBJECT_ID('dbo.Purchases', 'U') IS NULL
CREATE TABLE dbo.Purchases (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ObjectName NVARCHAR(200) NOT NULL,
    Material NVARCHAR(200) NOT NULL,
    Quantity NVARCHAR(100) NOT NULL,
    Priority NVARCHAR(100) NOT NULL,
    Status NVARCHAR(100) NOT NULL,
    Comment NVARCHAR(500) NULL
);

IF OBJECT_ID('dbo.Equipment', 'U') IS NULL
CREATE TABLE dbo.Equipment (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    EquipmentName NVARCHAR(200) NOT NULL,
    EquipmentType NVARCHAR(200) NOT NULL,
    Status NVARCHAR(100) NOT NULL
);

IF OBJECT_ID('dbo.Employees', 'U') IS NULL
CREATE TABLE dbo.Employees (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    FullName NVARCHAR(250) NOT NULL,
    Phone NVARCHAR(100) NOT NULL,
    Address NVARCHAR(300) NOT NULL,
    JobTitle NVARCHAR(200) NOT NULL,
    ObjectName NVARCHAR(200) NOT NULL,
    Status NVARCHAR(100) NOT NULL,
    Salary NVARCHAR(100) NOT NULL,
    HireDate NVARCHAR(100) NOT NULL,
    Comment NVARCHAR(500) NULL
);

IF OBJECT_ID('dbo.Clients', 'U') IS NULL
CREATE TABLE dbo.Clients (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    FullName NVARCHAR(250) NOT NULL,
    Phone NVARCHAR(100) NOT NULL,
    Status NVARCHAR(100) NOT NULL
);

IF OBJECT_ID('dbo.Users', 'U') IS NULL
CREATE TABLE dbo.Users (
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Login NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    Email NVARCHAR(200) NULL
);

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Login = N'admin')
INSERT INTO dbo.Users (Login, Password, Email) VALUES (N'admin', N'admin', NULL);
");
        }

        private static string SelectConnectionString()
        {
            string configured = ConnectionString;
            string[] candidates =
            {
                configured,
                @"Data Source=.\SQLEXPRESS;Initial Catalog=RabotaDb;Integrated Security=True;TrustServerCertificate=True",
                @"Data Source=localhost\SQLEXPRESS;Initial Catalog=RabotaDb;Integrated Security=True;TrustServerCertificate=True",
                @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=RabotaDb;Integrated Security=True;TrustServerCertificate=True"
            };

            Exception lastError = null;
            foreach (string candidate in candidates)
            {
                try
                {
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(candidate);
                    builder.InitialCatalog = "master";
                    using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                    {
                        connection.Open();
                        return candidate;
                    }
                }
                catch (Exception ex)
                {
                    lastError = ex;
                }
            }

            throw new InvalidOperationException("Не удалось подключиться к SQL Server. Проверьте строку подключения RabotaDb в файле РАБОТА.exe.config.", lastError);
        }

        public static void RefreshAll()
        {
            isRefreshing = true;
            try
            {
                FillTable(Objects, "SELECT Id, ObjectName AS [Название объекта], Foreman AS [Прораб], Status AS [Статус] FROM dbo.Objects ORDER BY Id");
                FillTable(Purchases, "SELECT Id, ObjectName AS [Объект], Material AS [Материал], Quantity AS [Кол-во], Priority AS [Приоритет], Status AS [Статус], ISNULL(Comment, N'') AS [Комментарий] FROM dbo.Purchases ORDER BY Id");
                FillTable(Equipment, "SELECT Id, EquipmentName AS [Название техники], EquipmentType AS [Тип], Status AS [Состояние] FROM dbo.Equipment ORDER BY Id");
                FillTable(Employees, "SELECT Id, FullName AS [ФИО], Phone AS [Телефон], Address AS [Адрес], JobTitle AS [Должность], ObjectName AS [Объект], Status AS [Статус], Salary AS [Зарплата], HireDate AS [Дата приема], ISNULL(Comment, N'') AS [Комментарий] FROM dbo.Employees ORDER BY Id");
                FillTable(Clients, "SELECT Id, FullName AS [ФИО], Phone AS [Телефон], Status AS [Статус] FROM dbo.Clients ORDER BY Id");
            }
            finally
            {
                isRefreshing = false;
            }
        }

        private static void FillTable(DataTable table, string sql)
        {
            table.Clear();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, connection))
            {
                adapter.Fill(table);
            }
        }

        private static void ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private static object ExecuteScalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteScalar();
            }
        }

        public static void AddObject(string name, string foreman, string status)
        {
            ExecuteNonQuery("INSERT INTO dbo.Objects (ObjectName, Foreman, Status) VALUES (@name, @foreman, @status)",
                new SqlParameter("@name", name),
                new SqlParameter("@foreman", foreman),
                new SqlParameter("@status", status));
            RefreshAll();
        }

        public static void AddPurchase(string objectName, string material, string count, string priority, string status, string comment)
        {
            ExecuteNonQuery("INSERT INTO dbo.Purchases (ObjectName, Material, Quantity, Priority, Status, Comment) VALUES (@objectName, @material, @count, @priority, @status, @comment)",
                new SqlParameter("@objectName", objectName),
                new SqlParameter("@material", material),
                new SqlParameter("@count", count),
                new SqlParameter("@priority", priority),
                new SqlParameter("@status", status),
                new SqlParameter("@comment", (object)comment ?? DBNull.Value));
            RefreshAll();
        }

        public static void AddEquipment(string name, string type, string status)
        {
            ExecuteNonQuery("INSERT INTO dbo.Equipment (EquipmentName, EquipmentType, Status) VALUES (@name, @type, @status)",
                new SqlParameter("@name", name),
                new SqlParameter("@type", type),
                new SqlParameter("@status", status));
            RefreshAll();
        }

        public static void AddEmployee(string fio, string phone, string address, string job, string objectName, string status, string salary, string date, string comment)
        {
            ExecuteNonQuery("INSERT INTO dbo.Employees (FullName, Phone, Address, JobTitle, ObjectName, Status, Salary, HireDate, Comment) VALUES (@fio, @phone, @address, @job, @objectName, @status, @salary, @date, @comment)",
                new SqlParameter("@fio", fio),
                new SqlParameter("@phone", phone),
                new SqlParameter("@address", address),
                new SqlParameter("@job", job),
                new SqlParameter("@objectName", objectName),
                new SqlParameter("@status", status),
                new SqlParameter("@salary", salary),
                new SqlParameter("@date", date),
                new SqlParameter("@comment", (object)comment ?? DBNull.Value));
            RefreshAll();
        }

        public static void AddClient(string fio, string phone, string status)
        {
            ExecuteNonQuery("INSERT INTO dbo.Clients (FullName, Phone, Status) VALUES (@fio, @phone, @status)",
                new SqlParameter("@fio", fio),
                new SqlParameter("@phone", phone),
                new SqlParameter("@status", status));
            RefreshAll();
        }

        public static bool ValidateUser(string login, string password)
        {
            if (!HasText(login, password))
            {
                return false;
            }

            object result = ExecuteScalar("SELECT COUNT(1) FROM dbo.Users WHERE Login = @login AND Password = @password",
                new SqlParameter("@login", login.Trim()),
                new SqlParameter("@password", password));
            return Convert.ToInt32(result) > 0;
        }

        public static bool RegisterUser(string login, string password)
        {
            return RegisterUser(login, password, string.Empty);
        }

        public static bool RegisterUser(string login, string password, string email)
        {
            login = login.Trim();
            object exists = ExecuteScalar("SELECT COUNT(1) FROM dbo.Users WHERE Login = @login", new SqlParameter("@login", login));
            if (Convert.ToInt32(exists) > 0)
            {
                return false;
            }

            ExecuteNonQuery("INSERT INTO dbo.Users (Login, Password, Email) VALUES (@login, @password, @email)",
                new SqlParameter("@login", login),
                new SqlParameter("@password", password),
                new SqlParameter("@email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email.Trim()));
            return true;
        }

        public static DataRow FindRow(DataTable table, int id)
        {
            DataRow[] rows = table.Select("Id = " + id);
            return rows.Length == 0 ? null : rows[0];
        }

        public static void DeleteRow(DataTable table, int id)
        {
            if (ReferenceEquals(table, Objects)) ExecuteNonQuery("DELETE FROM dbo.Objects WHERE Id = @id", new SqlParameter("@id", id));
            if (ReferenceEquals(table, Purchases)) ExecuteNonQuery("DELETE FROM dbo.Purchases WHERE Id = @id", new SqlParameter("@id", id));
            if (ReferenceEquals(table, Equipment)) ExecuteNonQuery("DELETE FROM dbo.Equipment WHERE Id = @id", new SqlParameter("@id", id));
            if (ReferenceEquals(table, Employees)) ExecuteNonQuery("DELETE FROM dbo.Employees WHERE Id = @id", new SqlParameter("@id", id));
            if (ReferenceEquals(table, Clients)) ExecuteNonQuery("DELETE FROM dbo.Clients WHERE Id = @id", new SqlParameter("@id", id));
            RefreshAll();
        }

        private static void SaveObjectRow(object sender, DataRowChangeEventArgs e)
        {
            if (isRefreshing || e.Action != DataRowAction.Change) return;
            ExecuteNonQuery("UPDATE dbo.Objects SET ObjectName=@name, Foreman=@foreman, Status=@status WHERE Id=@id",
                Parameter("@id", e.Row["Id"]),
                Parameter("@name", e.Row["Название объекта"]),
                Parameter("@foreman", e.Row["Прораб"]),
                Parameter("@status", e.Row["Статус"]));
        }

        private static void SavePurchaseRow(object sender, DataRowChangeEventArgs e)
        {
            if (isRefreshing || e.Action != DataRowAction.Change) return;
            ExecuteNonQuery("UPDATE dbo.Purchases SET ObjectName=@objectName, Material=@material, Quantity=@quantity, Priority=@priority, Status=@status, Comment=@comment WHERE Id=@id",
                Parameter("@id", e.Row["Id"]),
                Parameter("@objectName", e.Row["Объект"]),
                Parameter("@material", e.Row["Материал"]),
                Parameter("@quantity", e.Row["Кол-во"]),
                Parameter("@priority", e.Row["Приоритет"]),
                Parameter("@status", e.Row["Статус"]),
                Parameter("@comment", e.Row["Комментарий"]));
        }

        private static void SaveEquipmentRow(object sender, DataRowChangeEventArgs e)
        {
            if (isRefreshing || e.Action != DataRowAction.Change) return;
            ExecuteNonQuery("UPDATE dbo.Equipment SET EquipmentName=@name, EquipmentType=@type, Status=@status WHERE Id=@id",
                Parameter("@id", e.Row["Id"]),
                Parameter("@name", e.Row["Название техники"]),
                Parameter("@type", e.Row["Тип"]),
                Parameter("@status", e.Row["Состояние"]));
        }

        private static void SaveEmployeeRow(object sender, DataRowChangeEventArgs e)
        {
            if (isRefreshing || e.Action != DataRowAction.Change) return;
            ExecuteNonQuery("UPDATE dbo.Employees SET FullName=@fio, Phone=@phone, Address=@address, JobTitle=@job, ObjectName=@objectName, Status=@status, Salary=@salary, HireDate=@date, Comment=@comment WHERE Id=@id",
                Parameter("@id", e.Row["Id"]),
                Parameter("@fio", e.Row["ФИО"]),
                Parameter("@phone", e.Row["Телефон"]),
                Parameter("@address", e.Row["Адрес"]),
                Parameter("@job", e.Row["Должность"]),
                Parameter("@objectName", e.Row["Объект"]),
                Parameter("@status", e.Row["Статус"]),
                Parameter("@salary", e.Row["Зарплата"]),
                Parameter("@date", e.Row["Дата приема"]),
                Parameter("@comment", e.Row["Комментарий"]));
        }

        private static void SaveClientRow(object sender, DataRowChangeEventArgs e)
        {
            if (isRefreshing || e.Action != DataRowAction.Change) return;
            ExecuteNonQuery("UPDATE dbo.Clients SET FullName=@fio, Phone=@phone, Status=@status WHERE Id=@id",
                Parameter("@id", e.Row["Id"]),
                Parameter("@fio", e.Row["ФИО"]),
                Parameter("@phone", e.Row["Телефон"]),
                Parameter("@status", e.Row["Статус"]));
        }

        private static SqlParameter Parameter(string name, object value)
        {
            return new SqlParameter(name, value == null || value == DBNull.Value ? DBNull.Value : value);
        }

        public static void FillCombo(ComboBox comboBox, DataTable table, string displayColumn)
        {
            comboBox.Items.Clear();
            foreach (DataRow row in table.Rows)
            {
                comboBox.Items.Add(new DbItem((int)row["Id"], Convert.ToString(row[displayColumn])));
            }
        }

        public static void FillPurchaseCombo(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            foreach (DataRow row in Purchases.Rows)
            {
                string text = Convert.ToString(row["Объект"]) + " - " + Convert.ToString(row["Материал"]);
                comboBox.Items.Add(new DbItem((int)row["Id"], text));
            }
        }

        public static int SelectedId(ComboBox comboBox)
        {
            DbItem selected = comboBox.SelectedItem as DbItem;
            return selected == null ? 0 : selected.Id;
        }

        public static string SelectedText(ComboBox comboBox)
        {
            DbItem selected = comboBox.SelectedItem as DbItem;
            return selected == null ? Convert.ToString(comboBox.Text) : selected.Text;
        }

        public static bool HasText(params string[] values)
        {
            foreach (string value in values)
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    return false;
                }
            }

            return true;
        }

        public static void ClearInputs(params Control[] controls)
        {
            foreach (Control control in controls)
            {
                TextBox textBox = control as TextBox;
                if (textBox != null)
                {
                    textBox.Clear();
                    continue;
                }

                ComboBox comboBox = control as ComboBox;
                if (comboBox != null)
                {
                    comboBox.SelectedIndex = -1;
                    comboBox.Text = string.Empty;
                }
            }
        }

        public static DataGridView BindGrid(Form form, string name, DataTable table, int x, int y, int width, int height)
        {
            DataGridView grid = form.Controls[name] as DataGridView;
            if (grid == null)
            {
                grid = new DataGridView();
                grid.Name = name;
                grid.Location = new Point(x, y);
                grid.Size = new Size(width, height);
                grid.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                grid.AllowUserToAddRows = false;
                grid.AllowUserToDeleteRows = false;
                grid.ReadOnly = true;
                grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                grid.MultiSelect = false;
                grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                grid.BackgroundColor = Color.White;
                form.Controls.Add(grid);
                grid.BringToFront();
            }

            grid.DataSource = table;
            if (grid.Columns.Contains("Id"))
            {
                grid.Columns["Id"].Visible = false;
            }

            return grid;
        }

        public static DataGridView BindGridBetweenFooter(Form form, string name, DataTable table, Control topControl, Control footer)
        {
            int x = topControl.Left;
            int y = topControl.Bottom + 10;
            int width = topControl.Width;
            int footerTop = footer == null ? form.ClientSize.Height : footer.Top;
            int height = Math.Max(70, footerTop - y - 10);

            return BindGrid(form, name, table, x, y, width, height);
        }
    }
}

using System;
using System.Data;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Объекты
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.BindGridBetweenFooter(this, "objectsGrid", AppMemoryDatabase.Objects, panel2, panel7);
            button4.Click += AddObjectClick;
        }

        private void AddObjectClick(object sender, EventArgs e)
        {
            if (!AppMemoryDatabase.HasText(textBox1.Text, textBox2.Text, comboBox2.Text))
            {
                MessageBox.Show("Заполните название объекта, прораба и статус.");
                return;
            }

            AppMemoryDatabase.AddObject(textBox1.Text.Trim(), textBox2.Text.Trim(), comboBox2.Text.Trim());
            AppMemoryDatabase.ClearInputs(textBox1, textBox2, comboBox2);
            MessageBox.Show("Объект добавлен.");
        }
    }

    public partial class Обьекты_Изменить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(CreateObjectSelector(), AppMemoryDatabase.Objects, "Название объекта");
            AppMemoryDatabase.BindGridBetweenFooter(this, "objectsGrid", AppMemoryDatabase.Objects, panel2, panel7);
            button4.Click += SaveObjectClick;
        }

        private ComboBox CreateObjectSelector()
        {
            ComboBox combo = panel2.Controls["objectSelect"] as ComboBox;
            if (combo != null)
            {
                return combo;
            }

            ComboBox replacement = new ComboBox();
            replacement.Name = "objectSelect";
            replacement.Location = textBox1.Location;
            replacement.Size = textBox1.Size;
            textBox1.Visible = false;
            panel2.Controls.Add(replacement);
            replacement.BringToFront();
            return replacement;
        }

        private void SaveObjectClick(object sender, EventArgs e)
        {
            ComboBox select = CreateObjectSelector();
            int id = AppMemoryDatabase.SelectedId(select);
            DataRow row = AppMemoryDatabase.FindRow(AppMemoryDatabase.Objects, id);
            if (row == null)
            {
                MessageBox.Show("Выберите объект.");
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                row["Название объекта"] = textBox2.Text.Trim();
            }
            if (!string.IsNullOrWhiteSpace(textBox3.Text))
            {
                row["Прораб"] = textBox3.Text.Trim();
            }
            if (!string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                row["Статус"] = comboBox2.Text.Trim();
            }

            AppMemoryDatabase.ClearInputs(textBox2, textBox3, comboBox2, select);
            AppMemoryDatabase.FillCombo(select, AppMemoryDatabase.Objects, "Название объекта");
            MessageBox.Show("Объект изменен.");
        }
    }

    public partial class Объекты_Удалить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Objects, "Название объекта");
            AppMemoryDatabase.BindGridBetweenFooter(this, "objectsGrid", AppMemoryDatabase.Objects, panel2, panel7);
            button4.Click += DeleteObjectClick;
        }

        private void DeleteObjectClick(object sender, EventArgs e)
        {
            int id = AppMemoryDatabase.SelectedId(comboBox2);
            if (id == 0)
            {
                MessageBox.Show("Выберите объект.");
                return;
            }

            AppMemoryDatabase.DeleteRow(AppMemoryDatabase.Objects, id);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Objects, "Название объекта");
            MessageBox.Show("Объект удален.");
        }
    }

    public partial class Закупки
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox1, AppMemoryDatabase.Objects, "Название объекта");
            AppMemoryDatabase.BindGridBetweenFooter(this, "purchasesGrid", AppMemoryDatabase.Purchases, panel2, panel7);
            button4.Click += AddPurchaseClick;
        }

        private void AddPurchaseClick(object sender, EventArgs e)
        {
            string objectName = AppMemoryDatabase.SelectedText(comboBox1);
            if (!AppMemoryDatabase.HasText(objectName, textBox2.Text, textBox3.Text, comboBox2.Text, comboBox3.Text))
            {
                MessageBox.Show("Заполните объект, материал, количество, приоритет и статус.");
                return;
            }

            AppMemoryDatabase.AddPurchase(objectName, textBox2.Text.Trim(), textBox3.Text.Trim(), comboBox2.Text.Trim(), comboBox3.Text.Trim(), textBox6.Text.Trim());
            AppMemoryDatabase.ClearInputs(comboBox1, textBox2, textBox3, comboBox2, comboBox3, textBox6);
            MessageBox.Show("Закупка добавлена.");
        }
    }

    public partial class Закупки_Изменить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillPurchaseCombo(comboBox1);
            AppMemoryDatabase.BindGridBetweenFooter(this, "purchasesGrid", AppMemoryDatabase.Purchases, panel2, panel7);
            button4.Click += SavePurchaseClick;
        }

        private void SavePurchaseClick(object sender, EventArgs e)
        {
            DataRow row = AppMemoryDatabase.FindRow(AppMemoryDatabase.Purchases, AppMemoryDatabase.SelectedId(comboBox1));
            if (row == null)
            {
                MessageBox.Show("Выберите закупку.");
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox2.Text)) row["Материал"] = textBox2.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox3.Text)) row["Кол-во"] = textBox3.Text.Trim();
            if (!string.IsNullOrWhiteSpace(comboBox2.Text)) row["Приоритет"] = comboBox2.Text.Trim();
            if (!string.IsNullOrWhiteSpace(comboBox3.Text)) row["Статус"] = comboBox3.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox6.Text)) row["Комментарий"] = textBox6.Text.Trim();

            AppMemoryDatabase.ClearInputs(comboBox1, textBox2, textBox3, comboBox2, comboBox3, textBox6);
            AppMemoryDatabase.FillPurchaseCombo(comboBox1);
            MessageBox.Show("Закупка изменена.");
        }
    }

    public partial class Закупки_Удалить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillPurchaseCombo(comboBox2);
            AppMemoryDatabase.BindGridBetweenFooter(this, "purchasesGrid", AppMemoryDatabase.Purchases, panel2, panel7);
            button4.Click += DeletePurchaseClick;
        }

        private void DeletePurchaseClick(object sender, EventArgs e)
        {
            int id = AppMemoryDatabase.SelectedId(comboBox2);
            if (id == 0)
            {
                MessageBox.Show("Выберите закупку.");
                return;
            }

            AppMemoryDatabase.DeleteRow(AppMemoryDatabase.Purchases, id);
            AppMemoryDatabase.FillPurchaseCombo(comboBox2);
            MessageBox.Show("Закупка удалена.");
        }
    }

    public partial class Техника
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            comboBox2.Items.Clear();
            comboBox2.Items.AddRange(new object[] { "Исправна", "Неисправна", "На ремонте" });
            AppMemoryDatabase.BindGridBetweenFooter(this, "equipmentGrid", AppMemoryDatabase.Equipment, panel2, panel7);
            button4.Click += AddEquipmentClick;
        }

        private void AddEquipmentClick(object sender, EventArgs e)
        {
            if (!AppMemoryDatabase.HasText(textBox1.Text, textBox2.Text, comboBox2.Text))
            {
                MessageBox.Show("Заполните название техники, тип и состояние.");
                return;
            }

            AppMemoryDatabase.AddEquipment(textBox1.Text.Trim(), textBox2.Text.Trim(), comboBox2.Text.Trim());
            AppMemoryDatabase.ClearInputs(textBox1, textBox2, comboBox2);
            MessageBox.Show("Техника добавлена.");
        }
    }

    public partial class Техника_Изменить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Equipment, "Название техники");
            AppMemoryDatabase.BindGridBetweenFooter(this, "equipmentGrid", AppMemoryDatabase.Equipment, panel2, panel7);
            button4.Click += SaveEquipmentClick;
        }

        private void SaveEquipmentClick(object sender, EventArgs e)
        {
            DataRow row = AppMemoryDatabase.FindRow(AppMemoryDatabase.Equipment, AppMemoryDatabase.SelectedId(comboBox2));
            if (row == null)
            {
                MessageBox.Show("Выберите технику.");
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox1.Text)) row["Название техники"] = textBox1.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox3.Text)) row["Тип"] = textBox3.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox2.Text)) row["Состояние"] = textBox2.Text.Trim();

            AppMemoryDatabase.ClearInputs(comboBox2, textBox1, textBox2, textBox3);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Equipment, "Название техники");
            MessageBox.Show("Техника изменена.");
        }
    }

    public partial class Техника_Удалить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Equipment, "Название техники");
            AppMemoryDatabase.BindGridBetweenFooter(this, "equipmentGrid", AppMemoryDatabase.Equipment, panel2, panel7);
            button4.Click += DeleteEquipmentClick;
        }

        private void DeleteEquipmentClick(object sender, EventArgs e)
        {
            int id = AppMemoryDatabase.SelectedId(comboBox2);
            if (id == 0)
            {
                MessageBox.Show("Выберите технику.");
                return;
            }

            AppMemoryDatabase.DeleteRow(AppMemoryDatabase.Equipment, id);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Equipment, "Название техники");
            MessageBox.Show("Техника удалена.");
        }
    }

    public partial class Сотрудники
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox1, AppMemoryDatabase.Objects, "Название объекта");
            comboBox3.Items.Clear();
            comboBox3.Items.AddRange(new object[] { "Работает", "Выходной", "Отпуск", "Больничный" });
            AppMemoryDatabase.BindGridBetweenFooter(this, "employeesGrid", AppMemoryDatabase.Employees, panel2, panel7);
            button4.Click += AddEmployeeClick;
        }

        private void AddEmployeeClick(object sender, EventArgs e)
        {
            string fio = (textBox1.Text + " " + textBox4.Text + " " + textBox5.Text).Trim();
            string objectName = AppMemoryDatabase.SelectedText(comboBox1);
            if (!AppMemoryDatabase.HasText(textBox1.Text, textBox4.Text, textBox5.Text, textBox7.Text, textBox8.Text, textBox2.Text, objectName, comboBox3.Text, textBox9.Text, textBox10.Text))
            {
                MessageBox.Show("Заполните данные сотрудника.");
                return;
            }

            AppMemoryDatabase.AddEmployee(fio, textBox7.Text.Trim(), textBox8.Text.Trim(), textBox2.Text.Trim(), objectName, comboBox3.Text.Trim(), textBox9.Text.Trim(), textBox10.Text.Trim(), string.Empty);
            AppMemoryDatabase.ClearInputs(textBox1, textBox4, textBox5, textBox7, textBox8, textBox2, comboBox1, comboBox3, textBox9, textBox10);
            MessageBox.Show("Сотрудник добавлен.");
        }
    }

    public partial class Сотрудники_Изменить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox3, AppMemoryDatabase.Employees, "ФИО");
            AppMemoryDatabase.BindGridBetweenFooter(this, "employeesGrid", AppMemoryDatabase.Employees, panel2, panel7);
            button4.Click += SaveEmployeeClick;
        }

        private void SaveEmployeeClick(object sender, EventArgs e)
        {
            DataRow row = AppMemoryDatabase.FindRow(AppMemoryDatabase.Employees, AppMemoryDatabase.SelectedId(comboBox3));
            if (row == null)
            {
                MessageBox.Show("Выберите сотрудника.");
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox4.Text)) row["Телефон"] = textBox4.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox5.Text)) row["Должность"] = textBox5.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox7.Text)) row["Зарплата"] = textBox7.Text.Trim();

            AppMemoryDatabase.ClearInputs(comboBox3, textBox4, textBox5, textBox7);
            AppMemoryDatabase.FillCombo(comboBox3, AppMemoryDatabase.Employees, "ФИО");
            MessageBox.Show("Сотрудник изменен.");
        }
    }

    public partial class Сотрудники_Удалить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Employees, "ФИО");
            AppMemoryDatabase.BindGridBetweenFooter(this, "employeesGrid", AppMemoryDatabase.Employees, panel2, panel7);
            button4.Click += DeleteEmployeeClick;
        }

        private void DeleteEmployeeClick(object sender, EventArgs e)
        {
            int id = AppMemoryDatabase.SelectedId(comboBox2);
            if (id == 0)
            {
                MessageBox.Show("Выберите сотрудника.");
                return;
            }

            AppMemoryDatabase.DeleteRow(AppMemoryDatabase.Employees, id);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Employees, "ФИО");
            MessageBox.Show("Сотрудник удален.");
        }
    }

    public partial class Клиенты
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            comboBox2.Items.Clear();
            comboBox2.Items.AddRange(new object[] { "Новый", "Постоянный", "VIP" });
            AppMemoryDatabase.BindGridBetweenFooter(this, "clientsGrid", AppMemoryDatabase.Clients, panel2, panel7);
            button4.Click += AddClientClick;
        }

        private void AddClientClick(object sender, EventArgs e)
        {
            if (!AppMemoryDatabase.HasText(textBox1.Text, textBox2.Text, comboBox2.Text))
            {
                MessageBox.Show("Заполните ФИО клиента, телефон и статус.");
                return;
            }

            AppMemoryDatabase.AddClient(textBox1.Text.Trim(), textBox2.Text.Trim(), comboBox2.Text.Trim());
            AppMemoryDatabase.ClearInputs(textBox1, textBox2, comboBox2);
            MessageBox.Show("Клиент добавлен.");
        }
    }

    public partial class Клиенты_Изменить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox1, AppMemoryDatabase.Clients, "ФИО");
            comboBox2.Items.Clear();
            comboBox2.Items.AddRange(new object[] { "Новый", "Постоянный", "VIP" });
            AppMemoryDatabase.BindGridBetweenFooter(this, "clientsGrid", AppMemoryDatabase.Clients, panel2, panel7);
            button4.Click += SaveClientClick;
        }

        private void SaveClientClick(object sender, EventArgs e)
        {
            DataRow row = AppMemoryDatabase.FindRow(AppMemoryDatabase.Clients, AppMemoryDatabase.SelectedId(comboBox1));
            if (row == null)
            {
                MessageBox.Show("Выберите клиента.");
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox2.Text)) row["ФИО"] = textBox2.Text.Trim();
            if (!string.IsNullOrWhiteSpace(textBox3.Text)) row["Телефон"] = textBox3.Text.Trim();
            if (!string.IsNullOrWhiteSpace(comboBox2.Text)) row["Статус"] = comboBox2.Text.Trim();

            AppMemoryDatabase.ClearInputs(comboBox1, textBox2, textBox3, comboBox2);
            AppMemoryDatabase.FillCombo(comboBox1, AppMemoryDatabase.Clients, "ФИО");
            MessageBox.Show("Клиент изменен.");
        }
    }

    public partial class Клиенты_Удалить
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Clients, "ФИО");
            AppMemoryDatabase.BindGridBetweenFooter(this, "clientsGrid", AppMemoryDatabase.Clients, panel2, panel7);
            button4.Click += DeleteClientClick;
        }

        private void DeleteClientClick(object sender, EventArgs e)
        {
            int id = AppMemoryDatabase.SelectedId(comboBox2);
            if (id == 0)
            {
                MessageBox.Show("Выберите клиента.");
                return;
            }

            AppMemoryDatabase.DeleteRow(AppMemoryDatabase.Clients, id);
            AppMemoryDatabase.FillCombo(comboBox2, AppMemoryDatabase.Clients, "ФИО");
            MessageBox.Show("Клиент удален.");
        }
    }
}

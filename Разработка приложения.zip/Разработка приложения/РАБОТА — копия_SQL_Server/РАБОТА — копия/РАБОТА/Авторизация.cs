﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Авторизация : Form
    {
        public Авторизация()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!AppMemoryDatabase.ValidateUser(textBox1.Text, textBox2.Text))
            {
                MessageBox.Show("Неверный логин или пароль.");
                return;
            }

            Главная main = new Главная();

            main.StartPosition = FormStartPosition.Manual;
            main.Location = this.Location;

            main.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Авторизация_Load(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Регистрация reg = new Регистрация();

            reg.StartPosition = FormStartPosition.Manual;
            reg.Location = this.Location;

            reg.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

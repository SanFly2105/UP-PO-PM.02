﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Регистрация : Form
    {
        public Регистрация()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
            button1.Click += button1_Click;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Авторизация auth = new Авторизация();

            auth.StartPosition = FormStartPosition.Manual;
            auth.Location = this.Location;

            auth.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!AppMemoryDatabase.HasText(textBox1.Text, textBox2.Text))
            {
                MessageBox.Show("Введите логин и пароль.");
                return;
            }

            if (!AppMemoryDatabase.RegisterUser(textBox1.Text, textBox2.Text, textBox3.Text))
            {
                MessageBox.Show("Пользователь с таким логином уже существует.");
                return;
            }

            MessageBox.Show("Пользователь зарегистрирован. Теперь можно войти с этим логином и паролем.");

            Авторизация auth = new Авторизация();
            auth.StartPosition = FormStartPosition.Manual;
            auth.Location = this.Location;
            auth.Show();
            this.Hide();
        }
    }
}

﻿namespace РАБОТА
{
    partial class Клиенты_Удалить
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.объектыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.объектыBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(625, 17);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(107, 34);
            this.button17.TabIndex = 4;
            this.button17.Text = "Сотрудники";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(512, 17);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(107, 34);
            this.button16.TabIndex = 3;
            this.button16.Text = "Техника";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(399, 17);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(107, 34);
            this.button15.TabIndex = 2;
            this.button15.Text = "Закупки";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(286, 17);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(107, 34);
            this.button14.TabIndex = 1;
            this.button14.Text = "Объекты";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel7.Controls.Add(this.label12);
            this.panel7.Location = new System.Drawing.Point(-13, 803);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1200, 50);
            this.panel7.TabIndex = 34;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(379, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(446, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "© 2026 Строительная Компания | Современная система управления";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "Клиенты и компании";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(738, 17);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(107, 34);
            this.button18.TabIndex = 5;
            this.button18.Text = "Клиенты";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(34, 234);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1111, 200);
            this.panel2.TabIndex = 33;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "В работе",
            "Завершено",
            "Приостановлено"});
            this.comboBox2.Location = new System.Drawing.Point(30, 60);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(340, 24);
            this.comboBox2.TabIndex = 8;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(30, 134);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить объект";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Выберите клиента";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(253, 173);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(107, 34);
            this.button3.TabIndex = 32;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(851, 17);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(107, 34);
            this.button19.TabIndex = 6;
            this.button19.Text = "Выход";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(140, 173);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 34);
            this.button2.TabIndex = 31;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(173, 17);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(107, 34);
            this.button13.TabIndex = 0;
            this.button13.Text = "Главная";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(475, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Система Управления Строительной Компанией";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(27, 173);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 34);
            this.button1.TabIndex = 30;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel8.Controls.Add(this.button19);
            this.panel8.Controls.Add(this.button18);
            this.panel8.Controls.Add(this.button17);
            this.panel8.Controls.Add(this.button16);
            this.panel8.Controls.Add(this.button15);
            this.panel8.Controls.Add(this.button14);
            this.panel8.Controls.Add(this.button13);
            this.panel8.Location = new System.Drawing.Point(-4, 50);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1200, 70);
            this.panel8.TabIndex = 28;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-4, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 50);
            this.panel1.TabIndex = 27;
            // 
            // объектыBindingSource
            // 
            this.объектыBindingSource.DataSource = typeof(РАБОТА.Объекты);
            // 
            // Клиенты_Удалить
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 853);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Name = "Клиенты_Удалить";
            this.Text = "Клиенты_Удалить";
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.объектыBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource объектыBindingSource;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel1;
    }
}
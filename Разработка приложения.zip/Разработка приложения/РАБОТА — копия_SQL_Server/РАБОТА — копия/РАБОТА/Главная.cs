﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Главная : Form
    {
        public Главная()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            Объекты obj = new Объекты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Закупки obj = new Закупки();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Техника obj = new Техника();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Сотрудники obj = new Сотрудники();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Клиенты obj = new Клиенты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Объекты obj = new Объекты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Закупки obj = new Закупки();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Техника obj = new Техника();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Сотрудники obj = new Сотрудники();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Клиенты obj = new Клиенты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Выход obj = new Выход();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }
    }
}

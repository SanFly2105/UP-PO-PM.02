﻿using System;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Выход : Form
    {
        Timer timer = new Timer();

        public Выход()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;

            timer.Interval = 5000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();

            Авторизация obj = new Авторизация();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void Выход_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
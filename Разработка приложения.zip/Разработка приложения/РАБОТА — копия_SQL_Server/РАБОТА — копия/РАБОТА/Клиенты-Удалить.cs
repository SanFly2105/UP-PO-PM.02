﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace РАБОТА
{
    public partial class Клиенты_Удалить : Form
    {
        public Клиенты_Удалить()
        {
            InitializeComponent();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Главная obj = new Главная();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Объекты obj = new Объекты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Закупки obj = new Закупки();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Техника obj = new Техника();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Сотрудники obj = new Сотрудники();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Клиенты obj = new Клиенты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Клиенты obj = new Клиенты();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Клиенты_Изменить obj = new Клиенты_Изменить();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Клиенты_Удалить obj = new Клиенты_Удалить();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Выход obj = new Выход();

            obj.StartPosition = FormStartPosition.Manual;
            obj.Location = this.Location;

            obj.Show();
            this.Hide();
        }
    }
}
